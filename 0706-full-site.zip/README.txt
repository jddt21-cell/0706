將 index.html 上傳到網站根目錄即可使用。
支援 Apache / Nginx / cPanel / Plesk / Vercel / Netlify